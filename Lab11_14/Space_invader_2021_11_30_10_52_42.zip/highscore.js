function Highscore(){
  const highscoreUrl = "http://localhost:3000/getHighscore"
  
  this.sortHighscore = ()=>{
    
  }
  this.getHighscore = ()=>{
    var xhr = new XMLHttpRequest()
    xhr.open("GET",highscoreUrl)
    xhr.send()
    console.log(this.responseText)
    return this.responseText
  }
  this.showHighscore = ()=>{
    background(0)
    text('Start',width/2,height/2)
    textSize(12)
    fill(255,255,255)
    
    textSize(20)
    text("HIGHSCORES",width/2 - 200, height/5)
    
    textAlign(CENTER)
    
  }
  this.startClicked = (x,y)=>{
    return x >= 200 && x <=230 && y >= 180 && y <= 205
  }
}