function Mainmenu(){
  background(0)
  
}